//
//  ViewController.swift
//  Hamburguesas
//
//  Created by Mohamed Reyes on 07/10/16.
//  Copyright © 2016 Mohamed Reyes. All rights reserved.
//

import UIKit

class ViewController: UIViewController {


    @IBOutlet weak var labelPais: UILabel!
    
    @IBOutlet weak var labelHamburguesa: UILabel!
    
    let colores = Colores()
    let paises = ColeccionDePaises()
    let hamburguesas = ColeccionDeHamburguesa()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func dameHamburguesa() {
        /* labelPais.text = "Mexico";
        labelHamburguesa.text = "Vaquera"; */
        
        let colorFondoAleatorio = colores.regresaColorAleatorio()
        view.backgroundColor = colorFondoAleatorio
        view.tintColor = colorFondoAleatorio
        
        labelPais.text = paises.obtenPais()
        labelHamburguesa.text = hamburguesas.obtenHamburguesa()
        

    }

}

