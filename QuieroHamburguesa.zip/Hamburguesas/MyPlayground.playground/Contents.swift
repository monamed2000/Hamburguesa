//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"



    
    var paises = ["Argentina", "Brasil", "México", "Canadá", "Chile", "Alemania", "Francia", "España", "Portugal", "Italia", "Camerún", "Ghana", "Kenia", "Mozambique", "Nigeria", "Irán", "India", "Jordania", "Kuwait", "Qatar", "Venezuela", "Sudáfrica", "Japón", "China", "Tanzania"]
    
    func obtenPais()->String{
        let paisAleatorio : Int? = Int(arc4random()) % paises.count
        return paises[paisAleatorio!]
    }


obtenPais()


